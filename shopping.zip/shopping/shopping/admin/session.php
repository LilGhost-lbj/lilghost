<?
session_start();
session_name("Admin");
if(!session_is_registered("adm"))
	session_register("adm");
?>