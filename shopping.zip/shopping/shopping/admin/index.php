<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<title>�����̳�</title>
</HEAD>
<frameset  rows="100%,*">
    <frame name="main" src="main.php" marginwidth="0" marginheight="0" scrolling="auto" frameborder="0">
    <frame name="blank" src="../shared/blank.html" marginwidth="0" marginheight="0" scrolling="no" frameborder="0">
</frameset>

</HTML>
