<TABLE cellspacing=0 cellpadding=0 width="100%" border=0>
	<tr>
		<form action="index.php?page=search" method="post" name="search">
		<TD valign=center><IMG src="gifs/icon_search.gif" border=0>&nbsp;</TD>
		<Td width="100%"><input type=text size=20 name="keyword" class="text70" maxlength="20">&nbsp;&nbsp;&nbsp;<A title="����" class=top_menu href="javascript:do_search();">����</A></TD>
		<input type="Hidden" name="page" value="search">
		</form>
	</tr>
</TABLE>