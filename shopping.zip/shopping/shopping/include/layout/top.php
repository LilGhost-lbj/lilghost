<TABLE cellspacing=0 cellpadding=0 border=0>
  <TR valign=top align=left>
    <TD width=790>
	  <TABLE cellspacing=0 cellpadding=0 width="100%" border=0>
        <TR height=141> 
          <TD valign=top width=168 height=141 hspace="0" vspace="0"><a href="index.php"><img src="gifs/logo.gif" width="168" height="141" alt="" border="0"></a></TD>
          <TD valign=top width=1 height=141 hspace="0" background="gifs/1x4.gif" vspace="0"><img src="gifs/1x4.gif" width="1" height="4" alt="" border="0"></TD>
          <TD valign=middle width=599 bgcolor="#1C95CC" align="center" height=141>
           
		  </TD>
          <TD valign=top width=1 height=141 hspace="0" background="gifs/1x4.gif" vspace="0"><img src="gifs/1x4.gif" width="1" height="4" alt="" border="0"></TD>
          <TD width=22 height=141>
            <P></P>
		  </TD>
		</TR>
		</TABLE>
	  </TD>
	</TR>
</TABLE>